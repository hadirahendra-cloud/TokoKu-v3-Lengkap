# TokoKu v3 Lengkap — Siap Build APK dari HP

Proyek Android WebView offline yang membungkus `index.html` TokoKu v3 Lengkap.

## Cara build APK lewat HP dengan GitHub Actions

1. Buat/login akun GitHub.
2. Buat repository baru, misalnya `TokoKu-v3-Lengkap`.
3. Upload seluruh isi folder proyek ini ke repository (bukan ZIP di dalam repository).
4. Buka tab **Actions**.
5. Pilih workflow **Build TokoKu APK**.
6. Tekan **Run workflow** (jika repository baru dan workflow sudah terbaca).
7. Tunggu sampai proses selesai.
8. Buka hasil workflow tersebut, lalu bagian **Artifacts**.
9. Download `TokoKu-v3-Lengkap-debug`.
10. Ekstrak ZIP artifact dan install `app-debug.apk` di HP Android.

Workflow otomatis memakai Java 17 dan Gradle 8.7, lalu menghasilkan APK debug.

## Build dengan Android Studio

Buka folder proyek ini di Android Studio terbaru lalu jalankan:
`gradle :app:assembleDebug`

APK berada di:
`app/build/outputs/apk/debug/app-debug.apk`

## Catatan
- Data TokoKu disimpan lokal melalui WebView/LocalStorage.
- Tidak membutuhkan server untuk fitur utama.
- Fitur berbagi nota menggunakan Android share sheet ketika berjalan sebagai APK.
- APK debug cocok untuk penggunaan pribadi/testing. Untuk distribusi publik, buat signing key/release APK sendiri.
